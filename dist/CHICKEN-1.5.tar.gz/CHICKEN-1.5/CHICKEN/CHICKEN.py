
import webbrowser

webbrowser.open("https://drive.google.com/open?id=0B0y6-Hhc3-u8NjRYQ1RvckdNU0E")

print("chicken")
