from distutils.core import setup
setup(
  name = 'CHICKEN',
  packages = ['CHICKEN'],
  version = '1.5',
  description = 'CHICKEN',
  author = 'Mark Scoble',
  author_email = 'scoble.mr@gmail.com',
  url = 'https://github.com/Necrolisk/chicken',
  download_url = 'https://github.com/Necrolisk/chicken/tarball/1.5',
  keywords = ['chicken', 'CHICKEN'],
  classifiers = [],
)
